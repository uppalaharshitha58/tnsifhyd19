package Practicework;

public class NormalClass {

	int a =10; //instance variable
	static int b=20; //static variable
	
	
	//instance method
	String display() {
		return "Hello Display";
	}
	
	//static method
	public static String display1() {
		return "Hello static display";
	}
		 public static void main(String[] args) {
		        NormalClass normalObj = new NormalClass();
		        System.out.println(normalObj.display());
		        System.out.println(NormalClass.display1());
		        System.out.println(normalObj.a);
		        System.out.println(NormalClass.b);
	}
}

